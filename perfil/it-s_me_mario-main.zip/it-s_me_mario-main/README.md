<h3>About me </h3>  
- Physics Undergraduate at <a href="https://ufsc.br/">Federal University of Santa Catarina</a>
- Currently in a Full-Stack Web Dev Bootcamp by <a href="https://www.driven.com.br/">Driven Education</a>

<h3>My skills</h3>

  ![HTML](https://img.shields.io/badge/HTML-333333?style=flat&logo=html5&logoColor=D84012)
  ![CSS](https://img.shields.io/badge/CSS-333333?&style=flat&logo=css3&logoColor=006EB4)
  ![JavaScript](https://img.shields.io/badge/JavaScript-333333?style=flat&logo=javascript&logoColor=EAD41C)
  ![Python](https://img.shields.io/badge/-Python-333333?style=flat&logo=python&logoColor=yellow)
  ![Visual Studio Code](https://img.shields.io/badge/-Visual%20Studio%20Code-333333?style=flat&logo=visual-studio-code&logoColor=007ACC)

<h3>Contact</h3> 

         
